export declare class WechatService {
    private config;
    constructor();
    getChat(question: string): Promise<{
        answer: string;
    }>;
}
