"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WechatController = void 0;
const wechat_service_1 = require("./wechat.service");
const common_1 = require("@nestjs/common");
const crypto = require("crypto");
const xml2js = require("xml2js");
let WechatController = class WechatController {
    constructor(wechatService) {
        this.wechatService = wechatService;
    }
    verify(query) {
        const token = 'wechatlirh42';
        const { signature, timestamp, nonce, echostr } = query;
        const params = [token, timestamp, nonce].sort().join('');
        const sha1 = crypto.createHash('sha1').update(params).digest('hex');
        if (sha1 === signature) {
            return echostr;
        }
        else {
            return 'Verification failed!';
        }
    }
    async handleMessage(req, res) {
        const xmlData = req.body;
        const parser = new xml2js.Parser({ explicitArray: false });
        parser.parseString(xmlData, async (err, result) => {
            if (err) {
                return res.status(500).send('Invalid XML data');
            }
            const receivedMessage = result.xml;
            const AIRes = await this.wechatService.getChat(receivedMessage.Content);
            const responseMessage = {
                xml: {
                    ToUserName: receivedMessage.FromUserName,
                    FromUserName: receivedMessage.ToUserName,
                    CreateTime: Math.floor(Date.now() / 1000),
                    MsgType: 'text',
                    Content: AIRes.answer,
                },
            };
            const builder = new xml2js.Builder();
            const xmlResponse = builder.buildObject(responseMessage);
            console.log('response', responseMessage);
            res.set('Content-Type', 'text/xml');
            res.status(200).send(xmlResponse);
        });
    }
};
__decorate([
    (0, common_1.Get)('server'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], WechatController.prototype, "verify", null);
__decorate([
    (0, common_1.Post)('server'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], WechatController.prototype, "handleMessage", null);
WechatController = __decorate([
    (0, common_1.Controller)('wechat'),
    __metadata("design:paramtypes", [wechat_service_1.WechatService])
], WechatController);
exports.WechatController = WechatController;
//# sourceMappingURL=wechat.controller.js.map