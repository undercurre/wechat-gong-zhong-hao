"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WechatService = void 0;
const common_1 = require("@nestjs/common");
const base64 = require("base-64");
const crypto_js_1 = require("crypto-js");
const WebSocket = require("ws");
let WechatService = class WechatService {
    constructor() {
        this.config = {
            APPID: '1288b463',
            APISecret: 'YjExNmM2ODAyMmEyNzU1ZTVlMDFhNDJj',
            APIKey: 'bc22669633ed221cd5d15c36a9e15eb7',
            Uid: 'lirh42',
            sparkResult: '',
        };
    }
    getChat(question) {
        return new Promise((resolve, reject) => {
            const sendMsg = (text) => {
                console.log('发送信息，请求AI处理');
                const myUrl = getWebsocketUrl();
                const socket = new WebSocket(myUrl);
                let tres = '';
                socket.on('open', () => {
                    console.log('开启连接！！');
                    const params = {
                        header: {
                            app_id: this.config.APPID,
                            uid: 'lirh42',
                        },
                        parameter: {
                            chat: {
                                domain: 'general',
                                temperature: 0.5,
                                max_tokens: 1024,
                            },
                        },
                        payload: {
                            message: {
                                text: [
                                    { role: 'user', content: '你是谁' },
                                    { role: 'assistant', content: '我是AI助手' },
                                    { role: 'user', content: text },
                                ],
                            },
                        },
                    };
                    console.log('发送消息');
                    socket.send(JSON.stringify(params));
                });
                socket.on('message', (event) => {
                    const data = JSON.parse(event);
                    console.log('收到消息！！', data);
                    this.config.sparkResult += data.payload.choices.text[0].content;
                    tres += data.payload.choices.text[0].content;
                    if (data.header.code !== 0) {
                        console.log('出错了', data.header.code, ':', data.header.message);
                        socket.close();
                    }
                    if (data.header.code === 0) {
                        if (data.payload.choices.text && data.header.status === 2) {
                            this.config.sparkResult += data.payload.choices.text[0].content;
                            setTimeout(() => {
                                socket.close();
                            }, 1000);
                        }
                    }
                });
                socket.on('close', () => {
                    console.log('连接关闭！！');
                    console.log('本次回答', tres);
                    resolve({ answer: tres });
                    tres = '';
                    this.config.sparkResult = this.config.sparkResult + '\n';
                });
                socket.on('error', () => {
                    console.error('连接错误:');
                    reject();
                });
            };
            const getWebsocketUrl = () => {
                let url = 'wss://spark-api.xf-yun.com/v1.1/chat';
                const host = 'spark-api.xf-yun.com/v1.1/chat';
                const apiKeyName = 'api_key';
                const date = new Date().toUTCString();
                const algorithm = 'hmac-sha256';
                const headers = 'host date request-line';
                const signatureOrigin = `host: ${host}\ndate: ${date}\nGET /v1.1/chat HTTP/1.1`;
                const signatureSha = (0, crypto_js_1.HmacSHA256)(signatureOrigin, this.config.APISecret);
                const signature = crypto_js_1.enc.Base64.stringify(signatureSha);
                const authorizationOrigin = `${apiKeyName}="${this.config.APIKey}", algorithm="${algorithm}", headers="${headers}", signature="${signature}"`;
                const authorization = base64.encode(authorizationOrigin);
                url = `${url}?authorization=${authorization}&date=${encodeURI(date)}&host=${host}`;
                return url;
            };
            sendMsg(question);
        });
    }
};
WechatService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], WechatService);
exports.WechatService = WechatService;
//# sourceMappingURL=wechat.service.js.map