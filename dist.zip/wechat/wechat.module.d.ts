export declare class WechatModule {
}
