import { WechatService } from './wechat.service';
import { Request, Response } from 'express';
export declare class WechatController {
    private readonly wechatService;
    constructor(wechatService: WechatService);
    verify(query: any): any;
    handleMessage(req: Request, res: Response): Promise<void>;
}
