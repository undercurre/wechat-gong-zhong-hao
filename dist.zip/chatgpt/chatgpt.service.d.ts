export declare class ChatgptService {
    getChat(question: string): Promise<string>;
}
