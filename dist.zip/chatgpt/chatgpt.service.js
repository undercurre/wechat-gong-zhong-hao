"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatgptService = void 0;
const common_1 = require("@nestjs/common");
const openai_1 = require("openai");
let ChatgptService = class ChatgptService {
    async getChat(question) {
        const openai = new openai_1.default({
            apiKey: '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',
        });
        const completion = await openai.chat.completions.create({
            messages: [{ role: 'system', content: question }],
            model: 'gpt-3.5-turbo',
        });
        return completion.choices[0].message.content;
    }
};
ChatgptService = __decorate([
    (0, common_1.Injectable)()
], ChatgptService);
exports.ChatgptService = ChatgptService;
//# sourceMappingURL=chatgpt.service.js.map