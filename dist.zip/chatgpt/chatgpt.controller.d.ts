import { ChatgptService } from './chatgpt.service';
import { ChatgptDto } from './chatgpt.dto';
export declare class ChatgptController {
    private readonly chatgptService;
    constructor(chatgptService: ChatgptService);
    getChat(chatgptDto: ChatgptDto): Promise<string>;
}
