export declare class ChatgptModule {
}
