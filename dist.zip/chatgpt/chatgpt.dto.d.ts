export declare class ChatgptDto {
    readonly question: string;
}
