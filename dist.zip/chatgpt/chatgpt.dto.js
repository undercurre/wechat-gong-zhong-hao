"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatgptDto = void 0;
class ChatgptDto {
}
exports.ChatgptDto = ChatgptDto;
//# sourceMappingURL=chatgpt.dto.js.map