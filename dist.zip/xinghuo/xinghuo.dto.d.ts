export declare class XinghuoDto {
    readonly question: string;
}
