"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.XinghuoDto = void 0;
class XinghuoDto {
}
exports.XinghuoDto = XinghuoDto;
//# sourceMappingURL=xinghuo.dto.js.map