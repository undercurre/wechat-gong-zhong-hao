export declare class XinghuoModule {
}
