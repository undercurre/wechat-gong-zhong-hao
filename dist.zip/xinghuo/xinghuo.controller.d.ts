import { XinghuoService } from './xinghuo.service';
import { XinghuoDto } from './xinghuo.dto';
export declare class XinghuoController {
    private readonly xinghuoService;
    constructor(xinghuoService: XinghuoService);
    getChat(xinghuoDto: XinghuoDto): Promise<{
        answer: string;
    }>;
}
