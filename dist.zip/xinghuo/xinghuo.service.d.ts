export declare class XinghuoService {
    private config;
    constructor();
    getChat(question: string): Promise<{
        answer: string;
    }>;
}
